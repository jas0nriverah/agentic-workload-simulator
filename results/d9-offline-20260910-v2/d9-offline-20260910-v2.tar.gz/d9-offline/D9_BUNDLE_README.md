# Offline D9 simulator bundle

Start with docs/d9-salvage-20260910/REPORT.md and simulator/README.md in that directory.

Quick smoke command from the extracted root:

    python3 docs/d9-salvage-20260910/simulator/run.py predict --request docs/d9-salvage-20260910/simulator/example_request.json

Historical and native model comparisons, coefficients, predictions, compact native evidence, source hashes and focused tests are included. Prediction uses the Python standard library. Optional plotting/project workflows may require dependencies declared by the original project.

This is an offline candidate bundle, not a claim of literal D9 compliance. Hardware transfer remains unvalidated. Token/cache models are conditional on supplied workload descriptors.

Large CPU binaries and repeated per-case reconstruction ledgers are retained externally and are not included. Full raw-evidence reconstruction and CPU manifest regeneration require those original artifacts; their provenance paths and hashes remain recorded. Compact native and historical comparison inputs are included. PACKAGED_FILES.json binds the exact included source/results.
